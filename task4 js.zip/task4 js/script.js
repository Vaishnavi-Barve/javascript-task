document.addEventListener("DOMContentLoaded", function () {
    const recipes = [
        { name: "Omelette", ingredients: ["egg", "milk"], type: "breakfast" },
        { name: "Pancakes", ingredients: ["flour", "milk", "egg"], type: "breakfast" },
        { name: "Grilled Chicken", ingredients: ["chicken", "spices"], type: "lunch" },
        { name: "Pasta", ingredients: ["pasta", "cheese"], type: "dinner" }
    ];

    const searchInput = document.getElementById("search-input");
    const recipeFilter = document.getElementById("recipe-filter");
    const searchBtn = document.getElementById("search-btn");
    const recipeList = document.getElementById("recipe-list");

    searchBtn.addEventListener("click", function () {
        const searchText = searchInput.value.toLowerCase().trim();
        const selectedType = recipeFilter.value;
        displayRecipes(searchText, selectedType);
    });

    function displayRecipes(searchText, selectedType) {
        recipeList.innerHTML = "";

        const filteredRecipes = recipes.filter(recipe => {
            const matchesIngredients = recipe.ingredients.some(ingredient =>
                ingredient.includes(searchText)
            );
            const matchesType = selectedType === "all" || recipe.type === selectedType;

            return matchesIngredients && matchesType;
        });

        if (filteredRecipes.length === 0) {
            recipeList.innerHTML = "<p>No matching recipes found.</p>";
        } else {
            filteredRecipes.forEach(recipe => {
                const recipeDiv = document.createElement("div");
                recipeDiv.classList.add("recipe");
                recipeDiv.innerHTML = `<h3>${recipe.name}</h3><p>Type: ${recipe.type}</p>`;
                recipeList.appendChild(recipeDiv);
            });
        }
    }
});