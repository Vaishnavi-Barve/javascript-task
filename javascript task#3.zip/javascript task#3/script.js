// Select DOM elements
const taskInput = document.getElementById("taskInput");
const addTaskButton = document.getElementById("addTaskButton");
const taskList = document.getElementById("taskList");
const searchInput = document.getElementById("searchInput");

// Retrieve tasks from localStorage
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

// Render tasks to UI
function renderTasks(filteredTasks = tasks) {
  taskList.innerHTML = "";
  filteredTasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span>${task}</span>
      <div>
        <button class="edit-btn" onclick="editTask(${index})">Edit</button>
        <button onclick="deleteTask(${index})">Delete</button>
      </div>
    `;
    taskList.appendChild(li);
  });
}

// Add new task
function addTask() {
  const task = taskInput.value.trim();
  if (task === "") {
    alert("Task cannot be empty!");
    return;
  }
  tasks.push(task);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  renderTasks();
  taskInput.value = "";
}

// Edit task
function editTask(index) {
  const newTask = prompt("Edit task:", tasks[index]);
  if (newTask !== null && newTask.trim() !== "") {
    tasks[index] = newTask.trim();
    localStorage.setItem("tasks", JSON.stringify(tasks));
    renderTasks();
  }
}

// Delete task
function deleteTask(index) {
  tasks.splice(index, 1);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  renderTasks();
}

// Filter tasks based on search input
function filterTasks() {
  const query = searchInput.value.toLowerCase();
  const filteredTasks = tasks.filter(task => task.toLowerCase().includes(query));
  renderTasks(filteredTasks);
}

// Event listeners
addTaskButton.addEventListener("click", addTask);
searchInput.addEventListener("input", filterTasks);
document.addEventListener("DOMContentLoaded", renderTasks);