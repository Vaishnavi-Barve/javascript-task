// Article Data Storage
let articles = [];
let currentPage = 1;
const articlesPerPage = 4;

// DOM Elements
const articleForm = document.getElementById('article-form');
const newsFeed = document.getElementById('news-feed');
const paginationControls = document.getElementById('pagination');
const pageNumbersContainer = document.getElementById('page-numbers');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

// Event Listener for Form Submission
articleForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const imageUrl = document.getElementById('image-url').value;

    if (title && description) {
        const newArticle = {
            title,
            description,
            imageUrl: imageUrl || null
        };
        articles.push(newArticle);
        renderArticles();
        updatePagination();
    }
    
    articleForm.reset(); // Reset the form fields
});

// Function to Render Articles Based on Current Page
function renderArticles() {
    // Clear existing articles
    newsFeed.innerHTML = '';

    // Calculate start and end index for current page
    const startIndex = (currentPage - 1) * articlesPerPage;
    const endIndex = startIndex + articlesPerPage;

    // Slice articles for current page
    const currentArticles = articles.slice(startIndex, endIndex);

    currentArticles.forEach(article => {
        const articleElement = document.createElement('div');
        articleElement.classList.add('article');
        articleElement.innerHTML = `
            <h3>${article.title}</h3>
            <p>${article.description}</p>
            ${article.imageUrl ? `<img src="${article.imageUrl}" alt="${article.title}">` : ''}
        `;
        newsFeed.appendChild(articleElement);
    });
}

// Function to Update Pagination Controls
function updatePagination() {
    const totalPages = Math.ceil(articles.length / articlesPerPage);
    const pageNumbers = [];

    // Clear current page numbers
    pageNumbersContainer.innerHTML = '';

    // Create page number buttons
    for (let i = 1; i <= totalPages; i++) {
        const pageNumberBtn = document.createElement('button');
        pageNumberBtn.textContent = i;
        pageNumberBtn.onclick = () => goToPage(i);
        pageNumbers.push(pageNumberBtn);
    }

    pageNumbers.forEach(btn => pageNumbersContainer.appendChild(btn));

    // Show/hide previous and next buttons based on current page
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
}

// Function to Navigate to Previous Page
prevBtn.addEventListener('click', function() {
    if (currentPage > 1) {
        currentPage--;
        renderArticles();
        updatePagination();
    }
});

// Function to Navigate to Next Page
nextBtn.addEventListener('click', function() {
    const totalPages = Math.ceil(articles.length / articlesPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        renderArticles();
        updatePagination();
    }
});

// Function to Go to a Specific Page
function goToPage(pageNumber) {
    currentPage = pageNumber;
    renderArticles();
    updatePagination();
}

// Initial Render
renderArticles();
updatePagination();
